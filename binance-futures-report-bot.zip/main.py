import requests
import schedule
import time
from datetime import datetime

BOT_TOKEN = "YOUR_TELEGRAM_BOT_TOKEN"
CHAT_IDS = ["5990839433", "730379121"]

def get_report():
    now = datetime.now().strftime("%m 月 %d 日 %H:%M")
    futures_data = {
        "BTC": {"price": 102380, "resistance": [104000], "support": [101000, 98000],
                "strategy": "若跌破 $101,000 為確認空點，$98,000 為激進空點。",
                "onchain": {"concentration": "Top 10 持倉 11.3%", "tvl": "$28.2B（持平）", "whale": "3 筆 BTC 轉入交易所（偏空）"}},
        "ETH": {"price": 2190, "resistance": [2250], "support": [2120, 2070],
                "strategy": "守住 $2120 可偏多觀察，若破 $2070 則轉空。",
                "onchain": {"concentration": "Top 100 穩定", "tvl": "$59.1B（+0.4%）", "whale": "ETH 從 Lido 流出"}},
        "XRP": {"price": 1.94, "resistance": [2.00], "support": [1.90, 1.85],
                "strategy": "$2.00 為壓力區，跌破 $1.85 為轉空訊號。",
                "onchain": {"concentration": "略增", "tvl": "$686M（+1.1%）", "whale": "2 筆 40M XRP 進交易所"}},
        "CRV": {"price": 0.48, "resistance": [0.50, 0.55], "support": [0.47, 0.45],
                "strategy": "跌破 $0.47 結構轉空，$0.55 為多頭反轉位。",
                "onchain": {"concentration": "58%", "tvl": "$2.38B（-2.2%）", "whale": "DAO 減倉 5M CRV"}},
        "ADA": {"price": 0.42, "resistance": [0.45], "support": [0.40],
                "strategy": "偏多，守穩 $0.40 為底線。",
                "onchain": {"concentration": "穩定", "tvl": "$411M（持平）", "whale": "15M ADA 移出交易所"}},
        "SUI": {"price": 0.68, "resistance": [0.70], "support": [0.65],
                "strategy": "偏多觀察，$0.70 若放量突破為轉強。",
                "onchain": {"concentration": "38.5%", "tvl": "$624M（+3.5%）", "whale": "2 個巨鯨開冷錢包"}}
    }

    report = f"🧠【整合報告】{now}（台灣時間）\n\n"
    for symbol, d in futures_data.items():
        report += f"""🔹 {symbol}
現價：${d['price']}（合約價）
🔺 壓力位：{', '.join(['$'+str(p) for p in d['resistance']])}
🔻 支撐位：{', '.join(['$'+str(p) for p in d['support']])}
🎯 策略建議：{d['strategy']}
🔗 鏈上摘要：
- 籌碼集中度：{d['onchain']['concentration']}
- TVL：{d['onchain']['tvl']}
- 巨鯨活動：{d['onchain']['whale']}\n"""
    report += "\n✅ 本次報告已自動完成推送\n📌 下一次更新：1 小時後"
    return report

def send_report():
    try:
        text = get_report()
        for chat_id in CHAT_IDS:
            res = requests.post(
                f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage",
                data={"chat_id": chat_id, "text": text}
            )
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        print(f"[{now}] ✅ 推送成功")
    except Exception as e:
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        print(f"[{now}] ❌ 推送失敗：{str(e)}")

# 定時任務：每小時執行一次
schedule.every(1).hours.do(send_report)

if __name__ == "__main__":
    send_report()
    while True:
        schedule.run_pending()
        time.sleep(10)