# Binance Futures Report Bot

這是一個自動化的報告推送機器人，用於每小時向 Telegram 發送幣種報告。